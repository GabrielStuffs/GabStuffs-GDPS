<?php
include "incl/relationships/getGJUserList.php";
?>