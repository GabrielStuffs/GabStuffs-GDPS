<?php
include "incl/misc/getGJSongInfo.php";
?>