<?php
include "incl/relationships/acceptGJFriendRequest.php";
?>