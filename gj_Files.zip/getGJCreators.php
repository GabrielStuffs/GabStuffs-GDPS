<?php
include "incl/scores/getGJCreators.php";
?>