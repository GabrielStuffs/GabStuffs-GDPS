<?php
require "../incl/dashboardLib.php";
$dl = new dashboardLib();
$dl->printBox("<h1>Error 418</h1><img src='https://cdn.discordapp.com/attachments/267762647468998657/359821105353195532/sakujes_teapot.png' class='img-fluid'>image by Tygrysek", "", true);