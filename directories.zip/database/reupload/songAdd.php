<?php
header("Location: ../../../tools/songs/upload.php");
?>
