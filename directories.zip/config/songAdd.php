<?php
$api_key = "dc467dd431fc48eb0244b0aead929ccd";