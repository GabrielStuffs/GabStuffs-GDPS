<?php
$servername = "";
$port = 3306;
$username = "";
$password = "";
$dbname = "";
?>